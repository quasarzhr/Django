from app.utils import sanitize_filename, generate_slug

def test_sanitize_filename_removes_illegal_chars():
    filename = "my*illegal:file?.txt"
    clean = sanitize_filename(filename)
    assert "*" not in clean and ":" not in clean and "?" not in clean

def test_generate_slug_converts_to_lowercase():
    slug = generate_slug("Hello World!")
    assert slug == "hello-world"
