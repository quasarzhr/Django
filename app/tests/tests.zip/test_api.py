import pytest
from django.urls import reverse

@pytest.mark.django_db
def test_api_post_list(client):
    response = client.get(reverse('app:post-list'))
    assert response.status_code == 200
    assert 'application/json' in response['Content-Type']

@pytest.mark.django_db
def test_api_post_detail_not_found(client):
    response = client.get(reverse('app:post-detail', args=[999]))
    assert response.status_code == 404
